from xlwt import Workbook, Formula
wb=Workbook()
sheet1=wb.add_sheet("Sheet1")

for i in range(10):
    sheet1.write(i,0,i)

#sheet1.write(10,0,Formula('SUM(A1:A10)'))

wb.save('xlwt example.xls')
