import pymysql
from openpyxl import Workbook

#open database connection
db=pymysql.connect(host="localhost",user="root1",passwd="root1",db="sample-sql-file-10-rows")

#prepare a cursor object using cursor() method
#cursor=db.cursor()

#execute SQL query using execute()
#cursor.execute("SELECT VERSION()")

#fetch a single row using fetchone() method
#data=cursor.fetchall()
#print("Database version:%s"%data)

cursor=db.cursor()
#sql=('select username from user_details')
sql=input('Enter an SQL query')
cursor.execute(sql)
data=cursor.fetchall()
print(data)

#disconnect from server
#db.close()

book=Workbook()
sheet=book.active

for data1 in data:
    sheet.append(data1)

#for row in sheet.iter_rows(min_row=1, min_col=1, max_row=10, max_col=10):
    #for cell in row:
        #print(cell.value, end=" ")
        #print()

book.save('data1.xlsx')




