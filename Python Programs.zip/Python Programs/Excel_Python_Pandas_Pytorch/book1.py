Python 3.7.1 (v3.7.1:260ec2c36a, Oct 20 2018, 14:57:15) [MSC v.1915 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import torch
>>> import pandas
>>> df=pandas.read_excel(r"C:\\Users\Jyotsna\Desktop\book1.xlsx")
>>> df
   FULL_AMT  FULL_PAX  RUPEE_DENO  TICKET_BUS_NO
0        10         1          10           2640
1        16         1          16           2640
2        54         3          18           2640
3        14         1          14           2640
>>> hf=torch.from_numpy(df.values)
>>> hf
tensor([[  10,    1,   10, 2640],
        [  16,    1,   16, 2640],
        [  54,    3,   18, 2640],
        [  14,    1,   14, 2640]])
>>> cost=hf[0:3,0]
>>> pax=hf[0:3,1]
>>> deno=hf[0:3,2]
>>> bus_no=hf[0:3,3]
>>> cost
tensor([10, 16, 54])
>>> pax
tensor([1, 1, 3])
>>> deno
tensor([10, 16, 18])
>>> bus_no
tensor([2640, 2640, 2640])
>>> 
