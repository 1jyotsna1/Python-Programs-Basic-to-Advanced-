Python 3.7.1 (v3.7.1:260ec2c36a, Oct 20 2018, 14:57:15) [MSC v.1915 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import torch
>>> a=torch.tensor([0,1,2,3,4])
>>> a
tensor([0, 1, 2, 3, 4])
>>> a[0]
tensor(0)
>>> a[1]
tensor(1)
>>> a[-1]
tensor(4)
>>> a[-2]
tensor(3)
>>> a.size()
torch.Size([5])
>>> a.ndimension()
1
>>> a_col=a.view(5,1)
>>> a_col
tensor([[0],
        [1],
        [2],
        [3],
        [4]])
>>> a_col=a.view(-1,1)
>>> a_col
tensor([[0],
        [1],
        [2],
        [3],
        [4]])
>>> d=a[1:4]
>>> d
tensor([1, 2, 3])
>>> d=a[0:3]
>>> d
tensor([0, 1, 2])
>>> u=torch.tensor([1,0])
>>> v=torch.tensor([0,1])
>>> z=u+v
>>> z
tensor([1, 1])
>>> z=2*u #scalar product of tensor u
>>> z
tensor([2, 0])
>>> u=torch.tensor([1,2])
>>> v=torch.tensor([3,2])
>>> z=u*v
>>> z
tensor([3, 4])
>>> r=torch.dot(u,v)
>>> r
tensor(7)
>>> y=torch.tensor([1,2,3,-1])
>>> z=y+1
>>> z
tensor([2, 3, 4, 0])
>>> y.max()
tensor(3)
>>> t=torch.linspace(-2,2,steps=5)
>>> t
tensor([-2., -1.,  0.,  1.,  2.])
>>> t=torch.linspace(-2,2,steps=9)
>>> t
tensor([-2.0000, -1.5000, -1.0000, -0.5000,  0.0000,  0.5000,  1.0000,  1.5000,
         2.0000])
>>> t.mean()
tensor(0.)
>>> t.max()
tensor(2.)
>>> A=torch.tensor([[1,2,3],[1,3,4],[6,7,8]])
>>> A
tensor([[1, 2, 3],
        [1, 3, 4],
        [6, 7, 8]])
>>> A.ndimension()
2
>>> A.shape
torch.Size([3, 3])
>>> A.size()
torch.Size([3, 3])
>>> A[0,0:2]
tensor([1, 2])
>>> A[0:2,0]
tensor([1, 1])
>>> A[0:2,0:2]
tensor([[1, 2],
        [1, 3]])
>>> X=torch.tensor([[1,0],[0,1]])
>>> Y=torch.tensor([[2,1],[1,2]])
>>> Z=X+Y
>>> Z
tensor([[3, 1],
        [1, 3]])
>>> 2*Y #scalar product of Y
tensor([[4, 2],
        [2, 4]])
>>> X*Y #Hadamard product of X,Y
tensor([[2, 0],
        [0, 2]])
>>> C=torch.mm(X,Y)
>>> C
tensor([[2, 1],
        [1, 2]])
>>> 
