import cv2
import numpy as np
from matplotlib import pyplot as plt

img=cv2.imread('DetectiveConan.jpg',0)
dimensions=img.shape
height=img.shape[0]
width=img.shape[1]

print("The dimensions of the image are",dimensions)
print("Height is",height)
print("Width is",width)
print("\n")

n=int(input("Enter size of the original image to be captured:"))
print("\n")
print("The matrix form of the original image captured is:")
print("\n")

Q=np.zeros(shape=(n,n))
for i in range(0,n):
    for j in range(0,n):
       Q[i][j]=img[i][j]

for q in Q:
    print(q)

P=np.zeros(shape=(n,n))
for i in range(0,n):
    for j in range(0,n):
        P[i][j]=-1*img[i][j]-1*img[i][j+1]-1*img[i][j+2]-1*img[i+1][j]+8*img[i+1][j+1]-1*img[i+1][j+2]-1*img[i+2][j]-1*img[i+2][j+1]-1*img[i+2][j+2]

print("\n")
print("The matrix form after HPF masking the captured image is:")
print("\n")
for p in P:
    print(p)
    
plt.imshow(img)
plt.show()

laplacian=cv2.Laplacian(img,cv2.CV_64F)
sobelx=cv2.Sobel(img,cv2.CV_64F,1,0,ksize=5)
sobely=cv2.Sobel(img,cv2.CV_64F,0,1,ksize=5)

plt.subplot(2,2,1),plt.imshow(img,cmap='gray')
plt.title('Original'),plt.xticks([]),plt.yticks([])

plt.subplot(2,2,2),plt.imshow(laplacian,cmap='gray')
plt.title('Laplacian'),plt.xticks([]),plt.yticks([])

plt.subplot(2,2,3),plt.imshow(sobelx,cmap='gray')
plt.title('SobelX'),plt.xticks([]),plt.yticks([])

plt.subplot(2,2,4),plt.imshow(sobely,cmap='gray')
plt.title('SobelY'),plt.xticks([]),plt.yticks([])

plt.show()
cv2.waitKey(0)
cv2.destroyAllWindows()        
