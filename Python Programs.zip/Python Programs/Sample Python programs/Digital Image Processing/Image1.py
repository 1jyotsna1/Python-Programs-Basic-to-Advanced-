from PIL import Image
import numpy 
jpgfile=Image.open('DeathNote.jpg')
print(numpy.shape(Image))
jpgfile.show()
