import numpy as np
Parent1=np.random.randint(0,2,(1,10))
Parent2=np.random.randint(0,2,(1,10))
Child1=np.zeros(shape=(1,10))
Child2=np.zeros(shape=(1,10))

Gene_no=Parent1.size
print("Size of each Genome is",Gene_no)
#single point crossover using for loops

CrossOverPoint=np.random.randint(0,Gene_no+1)
print("CrossOverPoint is", CrossOverPoint)
for i in range(0, CrossOverPoint):
    Child1[0][i]=Parent1[0][i]
    Child2[0][i]=Parent2[0][i]
    

for i in range(CrossOverPoint,Gene_no):
    Child1[0][i]=Parent2[0][i]
    Child2[0][i]=Parent1[0][i]
    
for p1 in Parent1:
    print(p1)
    print("\n")

for p2 in Parent2:
    print(p2)
    print("\n")
    
for c1 in Child1:
    print(c1)
    print("\n")

for c2 in Child2:
    print(c2)
    


