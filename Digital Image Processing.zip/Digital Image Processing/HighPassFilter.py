import cv2
import numpy as np
from matplotlib import pyplot as plt

img=cv2.imread('DeathNote.jpg',0)
dimensions=img.shape
height=img.shape[0]
width=img.shape[1]

print("Dimensions of the image are:", dimensions)
print("Height is:", height)
print("Width is", width)

laplacian=cv2.Laplacian(img,cv2.CV_64F)
sobelx=cv2.Sobel(img,cv2.CV_64F,1,0,ksize=5)
sobely=cv2.Sobel(img,cv2.CV_64F,0,1,ksize=5)

sobelx8u=cv2.Sobel(img,cv2.CV_8U,1,0,ksize=5)

sobelx64f=cv2.Sobel(img,cv2.CV_64F,1,0,ksize=5)
abs_sobel64f=np.absolute(sobelx64f)
sobel_8u=np.uint8(abs_sobel64f)

plt.subplot(2,3,1),plt.imshow(img,cmap='gray')
plt.title('Original'),plt.xticks([]),plt.yticks([])

plt.subplot(2,3,2),plt.imshow(laplacian,cmap='gray')
plt.title('Laplacian'),plt.xticks([]),plt.yticks([])

plt.subplot(2,3,3),plt.imshow(sobelx,cmap='gray')
plt.title('SobelX'),plt.xticks([]),plt.yticks([])

plt.subplot(2,3,4),plt.imshow(sobely,cmap='gray')
plt.title('SobelY'),plt.xticks([]),plt.yticks([])

plt.subplot(2,3,5),plt.imshow(sobelx8u,cmap='gray')
plt.title('Sobelx8u'),plt.xticks([]),plt.yticks([])

plt.subplot(2,3,6),plt.imshow(sobel_8u,cmap='gray')
plt.title('Sobel_8u'),plt.xticks([]),plt.yticks([])

plt.show()
cv2.waitKey(0)
cv2.destroyAllWindows()

